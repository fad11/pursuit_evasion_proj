# pursuit_pybullet

2D (x, z) pursuit environment in PyBullet: **n pursuers driven by ONE RL agent** vs **m scripted evaders**.

```
pursuit_pybullet/
├── assets/
│   ├── pursuer_point_mass.urdf   1.0 kg, r 0.15 m, inertia 0.009   (red)
│   ├── evader_point_mass.urdf    0.8 kg, r 0.12 m, inertia 0.004608 (blue)
│   └── agent_specs.py            max_accel, max_speed, drag + check_urdf()
├── envs/
│   ├── config.py                 PursuitEnvConfig (all parameters, gravity is an input)
│   └── pursuer_env.py            PursuerEnv (gymnasium)
├── controllers/
│   ├── base.py                   View + BaseController (normalised action, gravity feed-forward, wall helpers)
│   ├── general.py                stationary, straight, zigzag, square, circular
│   └── evasion.py                pure_evasion, manoeuvring_evasion
└── demo.py                       --check (physics self-checks)  --compare  --controller NAME  --watch
```

Run everything from inside this folder (`assets`, `envs`, `controllers` are imported as top-level packages).

## Quick start
```bat
pip install numpy gymnasium pybullet
python demo.py --check                  :: run this first
python demo.py --compare
python demo.py --controller zigzag --watch --gravity 9.81
```
```python
from envs import PursuerEnv
env = PursuerEnv(n_pursuers=2, n_evaders=3, gravity=9.81,
                 evader_controllers=("zigzag", ("circular", {"radius": 3.0}), ["pure_evasion", "square"]))
obs, info = env.reset(seed=0)                       # action shape (2 * n_pursuers,)
obs, r, terminated, truncated, info = env.step(env.action_space.sample())
```
`evader_controllers`: one entry (used for all evaders) or one per evader. An entry is `"name"`,
`("name", {kwargs})`, a controller instance, or a **list = pool** (one is drawn every episode).
`env.set_evader_controllers(...)` and `env.update_config(gravity=..., capture_radius=...)` change things between episodes.

## Actuation (RL agent and evaders alike)
`action in [-1,1]` -> clipped -> `* max_accel` -> `* mass` -> `applyExternalForce` (every physics substep).
Acceleration = action * max_accel, force limit = max_accel * mass.  Hovering needs `max_accel > gravity`.
Clipping is per component, so a diagonal command can reach 1.41 * max_accel.

## World
Plane at z = 0 (floor, friction 0), gravity along -z, walls at x = +-arena_half_x, ceiling at arena_height.
Only x and z are used (no y force; y and v_y are reset to 0 if they drift).  Speed limit, walls and ceiling are
enforced after every control step.  Agent-agent collisions are off; capture = distance <= capture_radius.
Captured evaders are parked (mass 0) far away and their controllers stop.

## Observation / reward
Observation (size 4*n_p + 5*n_p*n_e + 2): per pursuer own position and velocity; per pursuer-evader pair relative
position, relative velocity, alive flag (zeros once captured); time left; gravity / max_accel.
Reward: progress towards evaders + 10 per capture + 10 when the last one is caught - 0.01 per step.
Info: n_captured, captured mask, min_distance, time, is_success, evader_controllers.

## Controllers
| name | behaviour |
|---|---|
| stationary | holds position (hovers under gravity) |
| straight | random heading, reflected at walls / floor / ceiling |
| zigzag | straight heading rotated by amplitude * sin(2 pi f t) |
| square | visits the 4 corners of a square, random direction |
| circular | vertical circle, centre chosen so it stays off floor and walls |
| pure_evasion | flees all pursuers, weighted by 1/time-to-go^2 (most threatening dominates), wall repulsion |
| manoeuvring_evasion | mirrored proportional navigation against the most threatening pursuer + periodic jinks + wall repulsion |

Controllers get the true state (`View`) and return a normalised action, so they use the same path as the RL policy.
