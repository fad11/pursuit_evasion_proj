"""
envs/pursuer_env.py - PyBullet pursuit env: n pursuers (ONE RL agent) vs m scripted evaders, 2D in x and z.

World      PyBullet (DIRECT, or GUI with render_mode="human"), plane.urdf at z = 0, gravity = cfg.gravity (-z).
           Bodies are loaded from assets/*.urdf (mass, inertia from the file).  Only x and z are used: forces have
           no y component and y / v_y are reset to 0 whenever they drift.  Walls, ceiling and speed limit are
           enforced after every control step; the plane is the floor.  Agent-agent collisions are disabled
           (capture is decided by distance).

Actuation  action in [-1, 1] -> clipped -> * max_accel -> * mass -> applyExternalForce (re-applied every physics
           substep, because Bullet clears external forces after each stepSimulation).  Evader controllers return
           the same normalised action, so they use the same path.

Action     Box(-1, 1, (2 * n_pursuers,)):  (ax, az) per pursuer.
Observation (float32, size 4*n_p + 5*n_p*n_e + 2)
           per pursuer:        own pos (x/L, (z-H/2)/(H/2)),  own vel / max_speed
           per (pursuer,evader): rel pos / (2L, H), rel vel / (sum of max speeds), alive flag  (zeros if captured)
           global:             time left, gravity / pursuer max_accel
Reward     k_progress * (distance closed to the nearest pursuer, summed over alive evaders, normalised)
           + capture_bonus per capture + finish_bonus when all are caught - time_penalty
End        terminated: all evaders captured.   truncated: max_steps.
Info       n_captured, captured (mask), min_distance, time, is_success, evader_controllers
"""
import warnings
from dataclasses import replace

import gymnasium as gym
import numpy as np
import pybullet as pb
import pybullet_data
from gymnasium import spaces

from assets.agent_specs import check_urdf
from controllers import build_controller
from controllers.base import View
from .config import PursuitEnvConfig


class PursuerEnv(gym.Env):
    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 20}

    def __init__(self, config=None, render_mode=None, **overrides):
        super().__init__()
        self.cfg = replace(config if config is not None else PursuitEnvConfig(), **overrides)
        self.cfg.validate()
        c = self.cfg
        self.render_mode = render_mode
        self.n_p, self.n_e = c.n_pursuers, c.n_evaders
        for spec in (c.pursuer_spec, c.evader_spec):
            for problem in check_urdf(spec):
                warnings.warn(problem)

        self.action_space = spaces.Box(-1.0, 1.0, (2 * self.n_p,), np.float32)
        obs_dim = 4 * self.n_p + 5 * self.n_p * self.n_e + 2
        self.observation_space = spaces.Box(-np.inf, np.inf, (obs_dim,), np.float32)

        self._connect_and_load()
        self.p_pos, self.p_vel = np.zeros((self.n_p, 2)), np.zeros((self.n_p, 2))
        self.e_pos, self.e_vel = np.zeros((self.n_e, 2)), np.zeros((self.n_e, 2))
        self.alive = np.ones(self.n_e, bool)
        self.controllers = [None] * self.n_e
        self._t = 0
        self.set_evader_controllers(c.evader_controllers)

    # =============================================================== PyBullet setup
    def _connect_and_load(self):
        c = self.cfg
        self.cid = pb.connect(pb.GUI if self.render_mode == "human" else pb.DIRECT)   # one client per env
        pb.setAdditionalSearchPath(pybullet_data.getDataPath(), physicsClientId=self.cid)
        pb.setGravity(0, 0, -c.gravity, physicsClientId=self.cid)
        pb.setTimeStep(c.physics_dt, physicsClientId=self.cid)

        self.plane = pb.loadURDF("plane.urdf", physicsClientId=self.cid)
        pb.changeDynamics(self.plane, -1, lateralFriction=0.0, restitution=0.0, physicsClientId=self.cid)

        flags = pb.URDF_USE_INERTIA_FROM_FILE            # use the URDF inertia instead of recomputing it
        self.p_ids, self.e_ids = [], []
        for ids, n, spec in ((self.p_ids, self.n_p, c.pursuer_spec), (self.e_ids, self.n_e, c.evader_spec)):
            for k in range(n):
                body = pb.loadURDF(spec.urdf_path, basePosition=[0, 0, 5.0 + k], flags=flags, physicsClientId=self.cid)
                pb.changeDynamics(body, -1, linearDamping=spec.drag, angularDamping=0.0, restitution=0.0,
                                  physicsClientId=self.cid)
                ids.append(body)
        # real masses as read back from the engine (source of truth for the force computation)
        self.p_mass = [pb.getDynamicsInfo(b, -1, physicsClientId=self.cid)[0] for b in self.p_ids]
        self.e_mass = [pb.getDynamicsInfo(b, -1, physicsClientId=self.cid)[0] for b in self.e_ids]
        everyone = self.p_ids + self.e_ids
        for i, a in enumerate(everyone):                 # no agent-agent collisions
            for b in everyone[i + 1:]:
                pb.setCollisionFilterPair(a, b, -1, -1, 0, physicsClientId=self.cid)

        if self.render_mode == "human":
            L, H = c.arena_half_x, c.arena_height
            pts = [[-L, 0, 0], [L, 0, 0], [L, 0, H], [-L, 0, H]]
            for i in range(4):
                pb.addUserDebugLine(pts[i], pts[(i + 1) % 4], [0.3, 0.3, 0.3], physicsClientId=self.cid)
            pb.resetDebugVisualizerCamera(1.9 * L, 0, 0, [0, 0, H / 2], physicsClientId=self.cid)

    def _write(self, body, pos, vel):
        pb.resetBasePositionAndOrientation(body, [pos[0], 0.0, pos[1]], [0, 0, 0, 1], physicsClientId=self.cid)
        pb.resetBaseVelocity(body, [vel[0], 0.0, vel[1]], [0, 0, 0], physicsClientId=self.cid)

    def _read(self, body):
        """-> pos (x, z), vel (vx, vz), off_plane (True if y / v_y drifted)."""
        p, _ = pb.getBasePositionAndOrientation(body, physicsClientId=self.cid)
        v, _ = pb.getBaseVelocity(body, physicsClientId=self.cid)
        return (np.array([p[0], p[2]]), np.array([v[0], v[2]]), abs(p[1]) > 1e-5 or abs(v[1]) > 1e-5)

    # =============================================================== public helpers
    def set_evader_controllers(self, specs):
        """Change the evaders' behaviour (takes effect at the next reset). 1 entry = broadcast, or one per evader."""
        specs = list(specs) if isinstance(specs, (list, tuple)) and not (
            isinstance(specs, tuple) and len(specs) == 2 and isinstance(specs[1], dict)) else [specs]
        assert len(specs) in (1, self.n_e), "need 1 controller spec or one per evader"
        self._ctrl_specs = specs * self.n_e if len(specs) == 1 else specs

    def update_config(self, **kw):
        """Change parameters between episodes (gravity, capture_radius, spawn_dist_range, max_steps, ...)."""
        for k, v in kw.items():
            assert hasattr(self.cfg, k), f"unknown config field {k!r}"
            setattr(self.cfg, k, v)
        self.cfg.validate()
        if "gravity" in kw:
            pb.setGravity(0, 0, -self.cfg.gravity, physicsClientId=self.cid)

    # =============================================================== reset
    def reset(self, *, seed=None, options=None):
        """options (optional): {"pursuer_pos": (n_p, 2), "evader_pos": (n_e, 2)} for a fixed start."""
        super().reset(seed=seed)
        rng, c = self.np_random, self.cfg
        p_pos, e_pos = self._spawn(rng, options or {})
        self.p_pos, self.e_pos = p_pos, e_pos
        self.p_vel, self.e_vel = np.zeros_like(p_pos), np.zeros_like(e_pos)
        self.alive[:] = True
        for k, b in enumerate(self.p_ids):
            self._write(b, p_pos[k], self.p_vel[k])
        for k, b in enumerate(self.e_ids):
            pb.changeDynamics(b, -1, mass=c.evader_spec.mass, physicsClientId=self.cid)   # undo "parked" (mass 0)
            self._write(b, e_pos[k], self.e_vel[k])
        self._t = 0
        self._build_controllers(rng)
        self.prev_d = self._nearest_dist()
        return self._obs(), self._info(0)

    def _spawn(self, rng, options):
        c, m = self.cfg, self.cfg.spawn_margin
        lo = np.array([-c.arena_half_x + m, m])
        hi = np.array([c.arena_half_x - m, c.arena_height - m])
        e_pos = rng.uniform(lo, hi, size=(self.n_e, 2))
        p_pos = np.zeros((self.n_p, 2))
        for i in range(self.n_p):
            cand = rng.uniform(lo, hi)                                     # fallback if no good spot is found
            for _ in range(200):
                anchor = e_pos[rng.integers(self.n_e)]
                ang, d = rng.uniform(0, 2 * np.pi), rng.uniform(*c.spawn_dist_range)
                trial = anchor + d * np.array([np.cos(ang), np.sin(ang)])
                if np.all(trial >= lo) and np.all(trial <= hi) and \
                        np.min(np.linalg.norm(e_pos - trial, axis=1)) > 2 * c.capture_radius:
                    cand = trial
                    break
            p_pos[i] = cand
        if "pursuer_pos" in options:
            p_pos = np.asarray(options["pursuer_pos"], float).reshape(self.n_p, 2)
        if "evader_pos" in options:
            e_pos = np.asarray(options["evader_pos"], float).reshape(self.n_e, 2)
        return p_pos, e_pos

    def _build_controllers(self, rng):
        for j, spec in enumerate(self._ctrl_specs):
            if isinstance(spec, list):                                      # pool: draw one per episode
                spec = spec[int(rng.integers(len(spec)))]
            self.controllers[j] = build_controller(spec)
            self.controllers[j].reset(self._view(j), rng)

    # =============================================================== step
    def step(self, action):
        c = self.cfg
        a_p = np.clip(np.asarray(action, float).reshape(self.n_p, 2), -1.0, 1.0)       # clip to [-1, 1]
        f_p = a_p * c.pursuer_spec.max_accel * np.array(self.p_mass)[:, None]          # * max_accel * mass  [N]
        f_e = np.zeros((self.n_e, 2))
        for j in range(self.n_e):
            if self.alive[j]:
                a_e = np.clip(self.controllers[j].act(self._view(j)), -1.0, 1.0)
                f_e[j] = a_e * c.evader_spec.max_accel * self.e_mass[j]

        for _ in range(c.n_substeps):                                               # Bullet clears forces every step
            for k, b in enumerate(self.p_ids):
                self._push(b, f_p[k])
            for j, b in enumerate(self.e_ids):
                if self.alive[j]:
                    self._push(b, f_e[j])
            pb.stepSimulation(physicsClientId=self.cid)
        self._t += 1

        self._sync_and_limit()
        newly = self._captures()
        d = self._nearest_dist()

        # reward: progress of every evader that was alive at the start of the step (captures included)
        prog = 0.0
        was_alive = self.alive | newly
        if np.any(was_alive):
            prog = np.sum((self.prev_d[was_alive] - d[was_alive])) / (c.pursuer_spec.max_speed * c.dt) / self.n_e
        reward = c.k_progress * prog + c.capture_bonus * newly.sum() - c.time_penalty
        terminated = not self.alive.any()
        if terminated:
            reward += c.finish_bonus
        truncated = (not terminated) and self._t >= c.max_steps
        self.prev_d = d
        return self._obs(), float(reward), bool(terminated), bool(truncated), self._info(int(newly.sum()))

    def _push(self, body, force_xz):
        pos, _ = pb.getBasePositionAndOrientation(body, physicsClientId=self.cid)
        pb.applyExternalForce(body, -1, [force_xz[0], 0.0, force_xz[1]], pos, pb.WORLD_FRAME, physicsClientId=self.cid)

    # =============================================================== state, limits, captures
    def _sync_and_limit(self):
        """Read the engine state; enforce y-lock, speed limit, walls/ceiling/floor; write back if corrected."""
        c = self.cfg
        for pos, vel, ids, spec in ((self.p_pos, self.p_vel, self.p_ids, c.pursuer_spec),
                                    (self.e_pos, self.e_vel, self.e_ids, c.evader_spec)):
            for k, b in enumerate(ids):
                if ids is self.e_ids and not self.alive[k]:
                    continue
                p, v, off = self._read(b)
                p, v, changed = self._limit(p, v, spec)
                if changed or off:
                    self._write(b, p, v)
                pos[k], vel[k] = p, v

    def _limit(self, p, v, spec):
        c, changed = self.cfg, False
        p, v = p.copy(), v.copy()
        speed = np.linalg.norm(v)
        if speed > spec.max_speed:
            v *= spec.max_speed / speed
            changed = True
        lo = np.array([-c.arena_half_x + spec.radius, spec.radius])
        hi = np.array([c.arena_half_x - spec.radius, c.arena_height - spec.radius])
        for k in range(2):
            if p[k] < lo[k]:
                p[k], changed = lo[k], True
                v[k] = -c.wall_restitution * v[k] if v[k] < 0 else v[k]
            elif p[k] > hi[k]:
                p[k], changed = hi[k], True
                v[k] = -c.wall_restitution * v[k] if v[k] > 0 else v[k]
        return p, v, changed

    def _captures(self):
        """Mark evaders within capture_radius of any pursuer as captured and park them. Returns the new-capture mask."""
        newly = np.zeros(self.n_e, bool)
        for j in range(self.n_e):
            if self.alive[j] and np.min(np.linalg.norm(self.p_pos - self.e_pos[j], axis=1)) <= self.cfg.capture_radius:
                newly[j] = True
        for j in np.flatnonzero(newly):
            self.alive[j] = False
            pb.changeDynamics(self.e_ids[j], -1, mass=0.0, physicsClientId=self.cid)     # static
            self._write(self.e_ids[j], [1000.0 + 5.0 * j, 5.0], [0.0, 0.0])              # park far away
        return newly

    def _nearest_dist(self):
        return np.min(np.linalg.norm(self.p_pos[:, None, :] - self.e_pos[None, :, :], axis=2), axis=0)

    def _view(self, j):
        c = self.cfg
        return View(pos=self.e_pos[j].copy(), vel=self.e_vel[j].copy(), pursuers_pos=self.p_pos.copy(),
                    pursuers_vel=self.p_vel.copy(), max_speed=c.evader_spec.max_speed,
                    max_accel=c.evader_spec.max_accel, gravity=c.gravity, half_x=c.arena_half_x,
                    height=c.arena_height, radius=c.evader_spec.radius, dt=c.dt, t=self._t * c.dt)

    # =============================================================== observation / info
    def _obs(self):
        c = self.cfg
        L, H = c.arena_half_x, c.arena_height
        rel_scale = np.array([2 * L, H])
        vs = c.pursuer_spec.max_speed + c.evader_spec.max_speed
        parts = []
        for i in range(self.n_p):
            parts += [(self.p_pos[i] - [0, H / 2]) / [L, H / 2], self.p_vel[i] / c.pursuer_spec.max_speed]
            for j in range(self.n_e):
                if self.alive[j]:
                    parts += [(self.e_pos[j] - self.p_pos[i]) / rel_scale, (self.e_vel[j] - self.p_vel[i]) / vs, [1.0]]
                else:
                    parts += [np.zeros(2), np.zeros(2), [0.0]]
        parts += [[1.0 - self._t / c.max_steps], [c.gravity / c.pursuer_spec.max_accel]]
        return np.concatenate(parts).astype(np.float32)

    def _info(self, new_captures):
        return {"n_captured": int((~self.alive).sum()), "new_captures": new_captures,
                "captured": (~self.alive).copy(), "min_distance": float(np.min(self._nearest_dist())),
                "time": self._t * self.cfg.dt, "is_success": bool(not self.alive.any()),
                "evader_controllers": [getattr(c, "name", "?") for c in self.controllers]}

    # =============================================================== rendering
    def render(self):
        if self.render_mode != "rgb_array":
            return None                       # "human": the GUI window already shows the scene
        c, s = self.cfg, self.cfg.render_size
        L, H = c.arena_half_x, c.arena_height
        view = pb.computeViewMatrix([0, -1.9 * L, H / 2], [0, 0, H / 2], [0, 0, 1], physicsClientId=self.cid)
        proj = pb.computeProjectionMatrixFOV(50, 1.0, 0.1, 200, physicsClientId=self.cid)
        rgba = pb.getCameraImage(s, s, view, proj, renderer=pb.ER_TINY_RENDERER, physicsClientId=self.cid)[2]
        return np.reshape(rgba, (s, s, 4))[:, :, :3].astype(np.uint8)

    def close(self):
        if pb.isConnected(self.cid):
            pb.disconnect(self.cid)
