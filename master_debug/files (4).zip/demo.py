"""
demo.py - try the environment without any learning.

    python demo.py --check                                  physics self-checks (run this FIRST, needs pybullet)
    python demo.py --compare                                every evader controller vs a simple scripted pursuer
    python demo.py --controller zigzag --episodes 3 --watch --gravity 9.81
    python demo.py --controller pure_evasion --n-pursuers 2 --n-evaders 3

The scripted pursuer here is only a stand-in for the RL agent: it flies at the nearest evader with a
velocity tracker + gravity feed-forward.
"""
import argparse
import sys
from dataclasses import replace

import numpy as np
import pybullet as pb

from assets import EVADER, PURSUER
from controllers import controller_names
from controllers.base import BaseController
from envs import PursuerEnv


# ------------------------------------------------------------------------------ stand-in pursuer
def scripted_pursuer(env, kp=4.0):
    """Normalised action (n_p * 2,): go to the nearest alive evader at top speed, hover against gravity."""
    spec, a = env.cfg.pursuer_spec, np.zeros((env.n_p, 2))
    alive = np.flatnonzero(env.alive)
    if len(alive) == 0:
        return a.ravel()
    for i in range(env.n_p):
        j = alive[np.argmin(np.linalg.norm(env.e_pos[alive] - env.p_pos[i], axis=1))]
        d = env.e_pos[j] - env.p_pos[i]
        v_des = spec.max_speed * d / (np.linalg.norm(d) + 1e-9)
        acc = kp * (v_des - env.p_vel[i]) + np.array([0.0, env.cfg.gravity])
        a[i] = np.clip(acc / spec.max_accel, -1, 1)
    return a.ravel()


def run(env, episodes, watch=False, seed=0):
    wins, times = 0, []
    for ep in range(episodes):
        env.reset(seed=seed + ep)
        done = False
        while not done:
            _, _, te, tr, info = env.step(scripted_pursuer(env))
            done = te or tr
            if watch:
                env.render()
        wins += info["is_success"]
        times.append(info["time"])
        print(f"  episode {ep + 1}: captured {info['n_captured']}/{env.n_e} in {info['time']:.1f} s")
    return wins / episodes, float(np.mean(times))


# ------------------------------------------------------------------------------ physics self-checks
class ConstantAction(BaseController):
    """Evader that always outputs the same normalised action (used to test the evader force path)."""
    name = "constant"

    def __init__(self, action):
        super().__init__()
        self.action = np.asarray(action, np.float32)

    def act(self, view):
        return self.action


def physics_checks():
    ok_all = True

    def report(name, ok, detail):
        nonlocal ok_all
        ok_all &= bool(ok)
        print(f"  [{'PASS' if ok else 'FAIL'}] {name}: {detail}")

    p0, e0 = replace(PURSUER, drag=0.0), replace(EVADER, drag=0.0)     # no drag -> clean analytic references
    far = dict(pursuer_spec=p0, evader_spec=e0, arena_height=100.0, n_pursuers=1, n_evaders=1)

    # 1) free fall: z(t) = z0 - g t^2 / 2
    env = PursuerEnv(gravity=9.81, **far)
    env.reset(seed=0, options={"pursuer_pos": [[0, 50]], "evader_pos": [[5, 50]]})
    for _ in range(10):                                                  # 0.5 s, pursuer applies no force
        env.step(np.zeros(2))
    drop, expected = 50 - env.p_pos[0, 1], 0.5 * 9.81 * 0.5 ** 2
    report("free fall", abs(drop - expected) < 0.03 * expected, f"dropped {drop:.4f} m, expected {expected:.4f} m")
    env.close()

    # 2) force path: a = action * max_accel (mass cancels), force = action * max_accel * mass
    env = PursuerEnv(gravity=0.0, evader_controllers=(ConstantAction([1.0, 0.0]),), **far)
    env.reset(seed=0, options={"pursuer_pos": [[-5, 50]], "evader_pos": [[5, 50]]})
    for _ in range(4):                                                   # 0.2 s at full action
        env.step(np.array([1.0, 0.0]))
    for name, v, spec, mass in (("pursuer", env.p_vel[0, 0], p0, env.p_mass[0]), ("evader", env.e_vel[0, 0], e0, env.e_mass[0])):
        exp = spec.max_accel * 0.2
        report(f"{name} acceleration", abs(v - exp) < 0.03 * exp,
               f"v = {v:.3f} m/s, expected {exp:.3f} (mass {mass:.2f} kg, force {spec.max_accel * mass:.1f} N)")
    report("engine mass = spec mass", np.isclose(env.p_mass[0], p0.mass) and np.isclose(env.e_mass[0], e0.mass),
           f"{env.p_mass[0]:.3f}/{env.e_mass[0]:.3f} kg")
    env.close()

    # 3) the motion stays in the x-z plane
    env = PursuerEnv(gravity=9.81, **{**far, "arena_height": 10.0})
    env.reset(seed=1)
    rng, max_y = np.random.default_rng(0), 0.0
    for _ in range(100):
        _, _, te, tr, _ = env.step(rng.uniform(-1, 1, 2))
        max_y = max(max_y, abs(pb.getBasePositionAndOrientation(env.p_ids[0], physicsClientId=env.cid)[0][1]))
        if te or tr:
            env.reset(seed=2)
    report("2D (y stays 0)", max_y < 1e-4, f"max |y| = {max_y:.2e} m")
    env.close()

    # 4) hover: action_z = g / max_accel keeps the altitude
    env = PursuerEnv(gravity=9.81, **far)
    env.reset(seed=0, options={"pursuer_pos": [[0, 50]], "evader_pos": [[5, 50]]})
    for _ in range(40):
        env.step(np.array([0.0, 9.81 / p0.max_accel]))
    report("hover", abs(env.p_pos[0, 1] - 50) < 0.02, f"altitude drift {env.p_pos[0, 1] - 50:+.4f} m over 2 s")
    env.close()

    # 5) plane as floor: a falling body comes to rest at z = radius
    env = PursuerEnv(gravity=9.81, pursuer_spec=p0, evader_spec=e0)
    env.reset(seed=0, options={"pursuer_pos": [[0, 3.0]], "evader_pos": [[6, 5.0]]})
    for _ in range(80):
        env.step(np.zeros(2))
    report("plane floor", abs(env.p_pos[0, 1] - p0.radius) < 0.03,
           f"rests at z = {env.p_pos[0, 1]:.3f} m (radius {p0.radius} m)")
    env.close()
    return ok_all


# ------------------------------------------------------------------------------ main
if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="physics self-checks")
    ap.add_argument("--compare", action="store_true", help="all evader controllers vs the scripted pursuer")
    ap.add_argument("--controller", default="zigzag", choices=controller_names())
    ap.add_argument("--episodes", type=int, default=3)
    ap.add_argument("--gravity", type=float, default=9.81)
    ap.add_argument("--n-pursuers", type=int, default=1)
    ap.add_argument("--n-evaders", type=int, default=1)
    ap.add_argument("--watch", action="store_true", help="open the PyBullet GUI")
    a = ap.parse_args()

    if a.check:
        print("physics self-checks:")
        sys.exit(0 if physics_checks() else 1)

    names = controller_names() if a.compare else [a.controller]
    for name in names:
        print(f"evader controller: {name}")
        env = PursuerEnv(render_mode="human" if a.watch else None, gravity=a.gravity, n_pursuers=a.n_pursuers,
                         n_evaders=a.n_evaders, evader_controllers=(name,))
        rate, t = run(env, a.episodes if not a.compare else 10, watch=a.watch)
        print(f"  -> all evaders caught in {rate:.0%} of episodes, mean episode time {t:.1f} s\n")
        env.close()
